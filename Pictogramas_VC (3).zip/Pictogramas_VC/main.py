import cv2
import os

# Caminho para a pasta de imagens
PASTA_IMAGENS = 'imagens'

# Tamanho padrão das imagens (para normalização)
TAMANHO_IMAGEM = (128, 128)  # Aumentado o tamanho do quadrado
